import React from 'react';
import logo from './logo.svg';
import './App.css';
import FileForm from './FileForm';

function App() {
  return (
    <div className="App">
      <FileForm />
    </div>
  );
}

export default App;
