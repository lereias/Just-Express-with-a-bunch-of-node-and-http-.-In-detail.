var seedData = {
	total: 5,
	items: [
	{
		text: "Set up AWS Account",
		done: false
	},
	{
		text: "Launch EC2 instance from AWS console",
		done: false
	},
	{
		text: "Update server and install Apache",
		done: false
	},
	{
		text: "Open port 80 on the firewall",
		done: false
	},
	{
		text: "Replace /var/www/html with git repo",
		done: false
	},
	]		
}