# A front-end only toDo App 
## Purpse: Simple front-end app for AWS deployment course students.

### Overview
Anything but elegant, it's nothing but Javascript, jQuery, HTML, CSS and a bit of frustration as I forgot how hard it is to live without state management the past several years. Requires as little web dev understanding as possible. 

It is the bones of the [materialize css](http://materializecss.com/) starter theme. 

### Technologies Used
* Front-end only
* jQuery
* materializecss
* localStorage

### Notes
The code is heavily commented and follows a very basic procedural structure. jQuery listeners stand in place of native JS listeners as more people are familiar with jQuery selection syntax.

